import pathlib
from setuptools import setup

HERE = pathlib.Path(__file__).parent

README = (HERE / "README.md").read_text()

setup(
        name="bytecodemacro",
        version="1.0.0",
)
