make needs to be run before anything because python needs to be added to
# pyhton-macro-library-backup
