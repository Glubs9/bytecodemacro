def hello_world(a):
    print("hello_world")
