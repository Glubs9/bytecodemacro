__version__ = "1.0.0"
from bytecodemacro.meta.macro_lib import *
